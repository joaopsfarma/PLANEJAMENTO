'use client'
import { useState } from "react";
import { Card, CardContent } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { format, differenceInDays, parseISO } from "date-fns";

export default function Page() {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({
    produto: "",
    descricao: "",
    dataPrevista: "",
    dataChegada: "",
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleAdd = () => {
    if (!form.produto || !form.descricao || !form.dataPrevista) return;
    setItems([...items, form]);
    setForm({ produto: "", descricao: "", dataPrevista: "", dataChegada: "" });
  };

  const calcularAtraso = (dataPrevista, dataChegada) => {
    const hoje = new Date();
    const prevista = parseISO(dataPrevista);
    const chegada = dataChegada ? parseISO(dataChegada) : hoje;
    const atraso = differenceInDays(chegada, prevista);
    return atraso > 0 ? atraso : 0;
  };

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">MV Suprimentos - Controle de Entregas</h1>
      <Card className="mb-6">
        <CardContent className="grid grid-cols-1 md:grid-cols-4 gap-2">
          <Input placeholder="Produto" name="produto" value={form.produto} onChange={handleChange} />
          <Input placeholder="Descrição" name="descricao" value={form.descricao} onChange={handleChange} />
          <Input type="date" name="dataPrevista" value={form.dataPrevista} onChange={handleChange} />
          <Input type="date" name="dataChegada" value={form.dataChegada} onChange={handleChange} />
          <div className="md:col-span-4 text-right"><Button onClick={handleAdd}>Adicionar</Button></div>
        </CardContent>
      </Card>
      <div className="grid gap-4">
        {items.map((item, idx) => {
          const atraso = calcularAtraso(item.dataPrevista, item.dataChegada);
          return (
            <Card key={idx}>
              <CardContent className="grid grid-cols-1 md:grid-cols-5 gap-2 text-sm">
                <div><strong>Produto:</strong><br />{item.produto}</div>
                <div><strong>Descrição:</strong><br />{item.descricao}</div>
                <div><strong>Data Prevista:</strong><br />{format(parseISO(item.dataPrevista), 'dd/MM/yyyy')}</div>
                <div><strong>Data Chegada:</strong><br />{item.dataChegada ? format(parseISO(item.dataChegada), 'dd/MM/yyyy') : '-'}</div>
                <div><strong>Dias de Atraso:</strong><br />
                  <span className={atraso > 0 ? "text-red-600 font-bold" : "text-green-600"}>{atraso}</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}