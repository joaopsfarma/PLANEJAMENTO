import '../styles/globals.css'

export const metadata = {
  title: 'MV Suprimentos',
  description: 'Controle de entregas',
}

export default function RootLayout({ children }) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  )
}